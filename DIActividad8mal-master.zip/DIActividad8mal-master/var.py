global ui
